class MnemoxResizable{

    makeItResizable(elementId){
        var element = document.getElementById(elementId);

        element.addEventListener('click', function init() {
            removeResizable(); 
            console.log("1");          
            element.removeEventListener('click', init, false);
            element.className = element.className + ' resizable';
            console.log("2");     
            var resizer = document.createElement('div');
            resizer.className = 'resizer';
            element.appendChild(resizer);
            console.log("3");     
            resizer.addEventListener('mousedown', initDrag, false);
            console.log("4");     
        }, false);


        var startX, startY, startWidth, startHeight;

        function initDrag(e) {
            startX = e.clientX;
            startY = e.clientY;
            startWidth = parseInt(document.defaultView.getComputedStyle(element).width, 10);
            startHeight = parseInt(document.defaultView.getComputedStyle(element).height, 10);
            document.documentElement.addEventListener('mousemove', doDrag, false);
            document.documentElement.addEventListener('mouseup', stopDrag, false);
        }

        function doDrag(e) {
            element.style.width = (startWidth + e.clientX - startX) + 'px';
            element.style.height = (startHeight + e.clientY - startY) + 'px';
        }

        function stopDrag(e) {
            document.documentElement.removeEventListener('mousemove', doDrag, false);   
            document.documentElement.removeEventListener('mouseup', stopDrag, false);
            //removeResizable();
        }

        function removeResizable(){
            let existingResizerElements = document.querySelectorAll('.resizer');
            if(existingResizerElements.length > 0){
                for(let i = 0; i < existingResizerElements.length; i++){
                    existingResizerElements[i].remove();
                }
            }
            let existingResizableElements = document.querySelectorAll('.resizable');
            if(existingResizableElements.length > 0){
                for(let i = 0; i < existingResizableElements.length; i++){
                    existingResizableElements[i].classList.remove('resizable');
                }
            }
        }
    }
}

var mnemoxResizable = new MnemoxResizable();

function makeItResizable(elementId){
    mnemoxResizable.makeItResizable(elementId);
}